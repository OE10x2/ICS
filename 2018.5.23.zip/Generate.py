import pygame
import random

f_num = []
f_des = []

destinations = []
distances = []
time = []
list_check = []
for _ in range(10000):
    list_check.append(True)
short = ["AC", "TS", "WS", "AA", "DL", "UA"]
cities = ["Ottawa", "Montreal", "Quebec", "Halifax", "Winnipeg", "Edmonton", "Calgary",
          "Vancouver", "Detroit", "Philadelphia", "New York", "Washington", "Boston",
          "Chicago", "Atlanta", "Houston", "Las Vegas", "Los Angeles", "San Francisco"]
companies = {"AC": "Air Canada", "TS": "Air Transat", "WS": "WestJet", "AA": "American Airlines",
             "DL": "Delta Airlines", "UA": "United Airlines"}
models = ["A318", "A319", "A320", "A321", "A330", "A350", "A380", "B737", "B747", "B757", "B767", "B777", "B787"]
locations = {"Ottawa": (814, 467), "Montreal": (835, 455), "Quebec": (848, 438),
             "Halifax": (882, 459), "Winnipeg": (712, 434), "Edmonton": (645, 397),
             "Calgary": (637, 409), "Vancouver": (589, 412), "Detroit": (786, 493),
             "Philadelphia": (832, 498), "New York": (836, 501), "Washington": (823, 515),
             "Boston": (850, 482), "Chicago": (759, 499), "Atlanta": (784, 563), "Houston": (707, 593),
             "Las Vegas": (596, 517), "Los Angeles": (568, 529), "San Francisco": (559, 500)}
Toronto = (804, 481)

def gen_flights():
    start = random.choice(short)
    loop = True
    while loop:
        a = random.randint(0, 9)
        b = random.randint(0, 9)
        c = random.randint(0, 9)
        if a == 0 and b == 0 and c == 0:
            d = random.randint(1, 9)
        else:
            d = random.randint(0, 9)
        if list_check[a*1000+b*100+c*10+d]:
            loop = False
            start += (str(a) + str(b) + str(c) + str(d))
            list_check[a*1000+b*100+c*10+d] = False

    return start

def gen_city():
    city = random.choice(cities)
    #print(locations[city])

def gen_time():
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    return [hour, minute]

for i in range(1000):
    answer = gen_flights()
    print(answer)
    city = gen_city()

"""
pygame.init()
window = pygame.display.set_mode((1366, 768), pygame.FULLSCREEN)
clock = pygame.time.Clock()
quit = False
while not quit:
    window.fill([65, 105, 225])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
    event = pygame.key.get_pressed()
    if event[pygame.K_ESCAPE]:
        quit = True
    pygame.display.update()
    clock.tick(60)
pygame.quit()
"""
