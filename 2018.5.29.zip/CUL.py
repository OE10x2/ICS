import pygame
import Generate
pygame.init()
sizes = (1366, 768)
window = pygame.display.set_mode(sizes, pygame.FULLSCREEN)
clock = pygame.time.Clock()
quit = False

back = pygame.transform.scale(pygame.image.load("Background.png"), (500, 500))
rect = back.get_rect()
rect.center = (sizes[0]/2, sizes[1]/2)

flights = Generate.final_generate()
data = Generate.return_data()

for stuff in flights:
    print(stuff)

while not quit:
    window.fill([65, 105, 225])
    pygame.event.get() # useless AF
    event = pygame.key.get_pressed()
    if event[pygame.K_ESCAPE]:
        quit = True
    window.blit(back, rect)
    pygame.display.update()
    clock.tick(60)
pygame.quit()