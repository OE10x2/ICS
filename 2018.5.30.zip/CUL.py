import pygame
import Generate
import datetime
pygame.init()
sizes = (1366, 768)
window = pygame.display.set_mode(sizes, pygame.FULLSCREEN)
clock = pygame.time.Clock()
quit = False
time = [datetime.datetime.today().year, datetime.datetime.today().month, datetime.datetime.today().day,
         datetime.datetime.today().hour, datetime.datetime.today().minute, datetime.datetime.today().second]
for item in range(len(time)):
    time[item] = str(time[item])

toronto = (804, 481)
back = pygame.transform.scale(pygame.image.load("Background.png"), (500, 500))
flight = pygame.transform.scale(pygame.image.load("Airplane.png"), (25, 25))
rect = back.get_rect()
rect.center = (sizes[0]/2, sizes[1]/2)
rect2 = flight.get_rect()
rect2.center = toronto
font1 = pygame.font.SysFont("Arial", 50)
logo = pygame.transform.scale(pygame.image.load("Logo.jpg"), (125, 125))
exit_logo = pygame.transform.scale(pygame.image.load("Exit.png"), (125, 125))

flights = Generate.final_generate()
data = Generate.return_data()
cnt = 0

while not quit:
    window.fill([65, 105, 225])
    pygame.event.get()
    if cnt % 60 == 0:
        for item in range(len(time)):
            time[item] = int(time[item])
        cnt = 0
        time[5] += 1
        if time[5] >= 60:
            time[4] += 1
            time[5] = 0
        if time[4] >= 60:
            time[3] += 1
            time[4] = 0
        if time[3] >= 24:
            time[2] += 1
            time[3] = 0
        if (time[1] == 2 and time[0] % 4 == 0 and time[2] >= 30)\
                or (time[1] in [4, 6, 9, 11] and time[2] >= 31)\
                or (time[1] == 2 and time[0] % 4 != 0 and time[2] >= 29)\
                or (time[1] in [1, 3, 5, 7, 8, 10, 12] and time[2] >= 32):
            time[1] += 1
            time[2] = 0
        if time[1] > 12:
            time[0] += 1
        for i in range(len(time)):
            if i != 0 and len(str(time[i])) != 2:
                word = str(time[i])
                word = '0' + word
                time[i] = word
            else:
                time[i] = str(time[i])
        print(' '.join(time))
    cnt += 1
    # draw
    window.blit(back, rect)
    window.blit(flight, rect2)
    window.blit(logo, (0, 0))
    pygame.draw.line(window, (255, 255, 255), (350, 125), (350, sizes[1]), 2)
    pygame.draw.line(window, (255, 255, 255), (0, 125), (sizes[0], 125), 3)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-350, 125), (sizes[0]-350, sizes[1]), 3)
    pygame.draw.line(window, (255, 255, 255), (350, sizes[1]-125), (sizes[0]-350, sizes[1]-125), 2)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-125, 0), (sizes[0]-125, 125), 2)
    window.blit(exit_logo, (sizes[0]-125, 0))

    mouse_pos = pygame.mouse.get_pos()
    mouse_key = pygame.mouse.get_pressed()
    if mouse_key[0] and sizes[0] >= mouse_pos[0] >= sizes[0]-125 and 125 >= mouse_pos[1] >= 0:
        quit = True

    pygame.display.update()
    clock.tick(60)
pygame.quit()