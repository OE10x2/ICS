import random
import datetime
import math

list_check = []
for _ in range(10000):
    list_check.append(True)
short = ["AC", "TS", "WS", "AA", "DL", "UA"]
cities = ["Ottawa", "Montreal", "Quebec City", "Halifax", "Winnipeg", "Edmonton", "Calgary",
          "Vancouver", "Detroit", "Philadelphia", "New York", "Washington", "Boston",
          "Chicago", "Atlanta", "Houston", "Las Vegas", "Los Angeles", "San Francisco"]
companies = {"AC": "Air Canada", "TS": "Air Transat", "WS": "WestJet", "AA": "American Airlines",
             "DL": "Delta Airlines", "UA": "United Airlines"}
models = ["A318", "A319", "A320", "A321", "A330", "A350", "A380", "B737", "B747", "B757", "B767", "B777", "B787"]
flights = []
today = datetime.datetime.today()
time = [today.year, today.month, today.day, today.hour, today.minute]
data = {"Ottawa": (351, (59, 68), (814, 467)),
        "Montreal": (503, (70, 87), (835, 455)),
        "Quebec City": (729, (90, 101), (848, 438)),
        "Halifax": (1266, (123, 125), (882, 459)),
        "Winnipeg": (1510, (154, 158), (712, 434)),
        "Edmonton": (2704, (247, 250), (645, 397)),
        "Calgary": (2711, (250, 260), (637, 409)),
        "Vancouver": (3359, (288, 310), (589, 412)),
        "Detroit": (333, (69, 88), (786, 493)),
        "Philadelphia": (542, (88, 103), (832, 498)),
        "New York": (553, (98, 112), (836, 501)),
        "Washington": (566, (82, 101), (823, 515)),
        "Boston": (693, (92, 116), (850, 482)),
        "Chicago": (704, (107, 124), (759, 499)),
        "Atlanta": (1185, (131, 144), (784, 563)),
        "Houston": (2095, (204, 218), (707, 593)),
        "Las Vegas": (3135, (284, 290), (596, 517)),
        "Los Angeles": (3495, (310, 333), (568, 529)),
        "San Francisco": (3645, (321, 337), (559, 500))}


def flight_number():
    start = random.choice(short)
    start1 = start
    loop = True
    while loop:
        a = random.randint(0, 9)
        b = random.randint(0, 9)
        c = random.randint(0, 9)
        if a == 0 and b == 0 and c == 0:
            d = random.randint(1, 9)
        else:
            d = random.randint(0, 9)
        if list_check[a*1000+b*100+c*10+d]:
            loop = False
            start += (str(a) + str(b) + str(c) + str(d))
            list_check[a*1000+b*100+c*10+d] = False
    return [start, start1]


def final_generate():
    real = flight_number()
    number = real[0]
    company = companies[real[1]]
    destination = random.choice(cities)
    departure1 = random.randint(0, 1439)
    arrival1 = departure1 + random.randint(data[destination][1][0], data[destination][1][1])
    three_hours = 180
    departure2 = (arrival1 + three_hours) % 1440
    arrival2 = (departure2 + arrival1 - departure1) % 1440
    model = random.choice(models)
    for s in flights:
        if s[3] == destination and abs(s[4] - departure1) <= 10:
            return False
    flights.append([number, company, "Toronto", destination, departure1, arrival1, model])
    flights.append([number, company, destination, "Toronto", departure2, arrival2, model])
    return True


for _ in range(1000):
    while not final_generate():
        final_generate()


def pos_cities(keyword):
    first = keyword.title()
    second = keyword.lower()
    out = []
    for s in cities:
        if first in s:
            out.append(s)
        elif second in s:
            out.append(s)
    return out


def direct(flight):
    results = []
    length = len(flight)
    for i in flights:
        partial = i[0][:length]
        if partial == flight:
            results.append(i)
    return results


def real_time():
    for item in range(len(time)):
        time[item] = int(time[item])
    time[4] += 1
    if time[4] >= 60:
        time[3] += 1
        time[4] = 0
    if time[3] >= 24:
        time[2] += 1
        time[3] = 0
    if (time[1] == 2 and time[0] % 4 == 0 and time[2] >= 30)\
        or (time[1] in [4, 6, 9, 11] and time[2] >= 31)\
        or (time[1] == 2 and time[0] % 4 != 0 and time[2] >= 29)\
        or (time[1] in [1, 3, 5, 7, 8, 10, 12] and time[2] >= 32):
        time[1] += 1
        time[2] = 0
    if time[1] > 12:
        time[0] += 1
    for i in range(len(time)):
        if i != 0 and len(str(time[i])) != 2:
            word = str(time[i])
            word = '0' + word
            time[i] = word
        else:
            time[i] = str(time[i])
    first = '-'.join(time[:3])
    second = ':'.join(time[3:])
    return first + " " + second


def binary(lower, higher, in_cnt, arc, AB):
    in_cnt += 1
    if in_cnt == 15: # when it runs 15 times, it narrows it down to less than 0.1.
        return round((lower+higher)/2, 3)
    elif abs(lower*2*math.sin(arc/lower/2) - AB) < abs(higher*2*math.sin(arc/higher/2) - AB):
        return binary(lower, higher-(higher-lower)/2, in_cnt, arc, AB)
    elif abs(lower*2*math.sin(arc/2/lower) - AB) > abs(higher*2*math.sin(arc/2/higher) - AB):
        return binary(lower+(higher-lower)/2, higher, in_cnt, arc, AB)


def big_board(time):
    top_5 = []
    flights.sort(key=lambda x: x[4])
    for i in range(len(flights)):
        if flights[i][4] >= time:
            top_5.append(flights[i])
            if i+1 == len(flights):
                top_5.append(flights[0])
                top_5.append(flights[1])
                top_5.append(flights[2])
                top_5.append(flights[3])
            elif i+2 == len(flights):
                top_5.append(flights[i+1])
                top_5.append(flights[0])
                top_5.append(flights[1])
                top_5.append(flights[2])
            elif i+3 == len(flights):
                top_5.append(flights[i+1])
                top_5.append(flights[i+2])
                top_5.append(flights[0])
                top_5.append(flights[1])
            elif i+4 == len(flights):
                top_5.append(flights[i+1])
                top_5.append(flights[i+2])
                top_5.append(flights[i+3])
                top_5.append(flights[0])
            else:
                top_5.append(flights[i+1])
                top_5.append(flights[i+2])
                top_5.append(flights[i+3])
                top_5.append(flights[i+4])
            break
    return top_5


#def search_number():