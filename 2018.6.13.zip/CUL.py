import pygame
import Generate
import math
pygame.init()
sizes = (1366, 768)
window = pygame.display.set_mode(sizes, pygame.FULLSCREEN)
clock = pygame.time.Clock()
out = False

toronto = (804, 481)
back = pygame.transform.scale(pygame.image.load("Background.png"), (500, 500))
model = pygame.transform.rotate(pygame.transform.scale(pygame.image.load("Airplane.png"), (25, 25)), -45)
rect = back.get_rect()
rect.center = (sizes[0]/2, sizes[1]/2)
font1 = pygame.font.SysFont("Calibri", 40)
font2 = pygame.font.SysFont("Calibri", 25)
logo = pygame.transform.scale(pygame.image.load("Logo.jpg"), (125, 125))
exit_logo = pygame.transform.scale(pygame.image.load("Exit.png"), (125, 125))
first_search = font2.render("FLIGHT NUMBER SEARCH:", False, (255, 255, 255))
flight_tracker = font1.render("FLIGHT TRACKER", False, (255, 255, 255))
second_search = font2.render("DESTINATION SEARCH:", False, (255, 255, 255))

flights = Generate.flights
cnt = 0
data = Generate.data
time = Generate.real_time()
current_time = int(time[11:][:2])*60+int(time[11:][3:])
active = []
result = []
words1 = ""
words2 = ""
display1 = 1060
display2 = 1060
bounds1 = False
bounds2 = False
first_box = False
second_box = False
left_box = True
result1 = False
result2 = False
convert = 225.801/3363  # convert between real life and ratios on screen

while not out:
    # initialize
    window.fill([65, 105, 225])
    pygame.event.get()
    mouse_pos = pygame.mouse.get_pos()
    mouse_key = pygame.mouse.get_pressed()
    if cnt == 60:
        time = Generate.real_time()
        current_time = int(time[11:][:2])*60+int(time[11:][3:])
        for s in flights:
            if s[4] <= current_time <= s[5]:
                if s in active:
                    continue
                active.append(s)
            else:
                if s in active:
                    active.remove(s)
        cnt = 0
    cnt += 1
    # draw
    big_board = Generate.big_board(current_time)
    print_time = font1.render(time, False, (255, 255, 255))
    window.blit(print_time, (500, 38))
    window.blit(back, rect)
    window.blit(logo, (0, 0))
    window.blit(flight_tracker, (150, 38))
    window.blit(first_search, (1050, 200))
    window.blit(second_search, (1050, 450))
    if left_box:
        departure = font2.render("DEPARTURE", False, (0, 0, 0))
        arrival = font2.render("ARRIVAL", False, (255, 255, 255))
    else:
        arrival = font2.render("ARRIVAL", False, (0, 0, 0))
        departure = font2.render("DEPARTURE", False, (255, 255, 255))
    window.blit(departure, (20, 160))
    window.blit(arrival, (220, 160))
    pygame.draw.line(window, (255, 255, 255), (350, 125), (350, sizes[1]), 2)
    pygame.draw.line(window, (255, 255, 255), (0, 125), (sizes[0], 125), 3)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-350, 125), (sizes[0]-350, sizes[1]), 3)
    pygame.draw.line(window, (255, 255, 255), (350, sizes[1]-125), (sizes[0]-350, sizes[1]-125), 2)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-125, 0), (sizes[0]-125, 125), 2)
    window.blit(exit_logo, (sizes[0]-125, 0))
    if 1350 >= mouse_pos[0] >= 1050 and 300 >= mouse_pos[1] >= 250:
        pygame.draw.rect(window, (0, 0, 0), (1050, 250, 300, 50), 2)
        pygame.draw.rect(window, (255, 255, 255), (1050, 500, 300, 50), 2)
    elif 1350 >= mouse_pos[0] >= 1050 and 550 >= mouse_pos[1] >= 500:
        pygame.draw.rect(window, (255, 255, 255), (1050, 250, 300, 50), 2)
        pygame.draw.rect(window, (0, 0, 0), (1050, 500, 300, 50), 2)
    else:
        pygame.draw.rect(window, (255, 255, 255), (1050, 250, 300, 50), 2)
        pygame.draw.rect(window, (255, 255, 255), (1050, 500, 300, 50), 2)
    for p in range(10):
        pygame.draw.line(window, (255, 255, 255), (0, 218+55*p), (350, 218+55*p))
    pygame.draw.line(window, (255, 255, 255), (175, 125), (175, 218))
    # big board
    if mouse_key[0] and 175 >= mouse_pos[0] >= 0 and 218 >= mouse_pos[1] >= 125:
        left_box = True
    elif mouse_key[0] and 350 >= mouse_pos[0] >= 175 and 218 >= mouse_pos[1] >= 125:
        left_box = False
    for p in range(len(big_board)):
        if left_box:
            if 350 >= mouse_pos[0] >= 0 and 225+55*(p+1) >= mouse_pos[1] >= 225+55*p:
                first = font2.render(str(big_board[p][0][0]), False, (0, 0, 0))
                second = font2.render(str(big_board[p][0][3]), False, (0, 0, 0))
                two_half = str(big_board[p][0][4] % 60)
                if len(two_half) == 1:
                    two_half = "0" + two_half
                third = font2.render(str(big_board[p][0][4] // 60) + ":" + two_half, False, (0, 0, 0))
            else:
                first = font2.render(str(big_board[p][0][0]), False, (255, 255, 255))
                second = font2.render(str(big_board[p][0][3]), False, (255, 255, 255))
                two_half = str(big_board[p][0][4] % 60)
                if len(two_half) == 1:
                    two_half = "0" + two_half
                third = font2.render(str(big_board[p][0][4] // 60) + ":" + two_half, False, (255, 255, 255))
            window.blit(first, (10, 225+55*p))
            window.blit(second, (120, 225+55*p))
            window.blit(third, (270, 225+55*p))
            #
        else:
            if 350 >= mouse_pos[0] >= 0 and 225+55*(p+1) >= mouse_pos[1] >= 225+55*p:
                first = font2.render(str(big_board[p][1][0]), False, (0, 0, 0))
                second = font2.render(str(big_board[p][1][2]), False, (0, 0, 0))
                two_half = str(big_board[p][1][4] % 60)
                if len(two_half) == 1:
                    two_half = "0" + two_half
                third = font2.render(str(big_board[p][1][4] // 60) + ":" + two_half, False, (0, 0, 0))
            else:
                first = font2.render(str(big_board[p][1][0]), False, (255, 255, 255))
                second = font2.render(str(big_board[p][1][2]), False, (255, 255, 255))
                two_half = str(big_board[p][1][4] % 60)
                if len(two_half) == 1:
                    two_half = "0" + two_half
                third = font2.render(str(big_board[p][1][4] // 60) + ":" + two_half, False, (255, 255, 255))
            window.blit(first, (10, 225+55*p))
            window.blit(second, (120, 225+55*p))
            window.blit(third, (270, 225+55*p))
    # map flight routes
    for i in active:
        if i[2] == "Toronto":
            current = data[i[3]][0] * ((current_time-i[4])/(i[5]-i[4]))
            one = toronto[0] - data[i[3]][2][0]
            two = toronto[1] - data[i[3]][2][1]
            ratio = abs(two/one)
            angle = abs(math.atan2(abs(two), abs(one)))/math.pi*180
            length = 0
            width = 0
            if one < 0:
                length = abs(current/math.sqrt(ratio*ratio+1))
            elif one > 0:
                length = -abs(current/math.sqrt(ratio*ratio+1))
            if two < 0:
                width = abs(length * ratio)
            elif two > 0:
                width = -abs(length * ratio)
            length *= convert
            width *= convert
            coordinates = (toronto[0]+length, toronto[1]+width)
            flight = model
            rect_in = flight.get_rect()
            rect_in.center = coordinates
            if one > 0 and two > 0:
                flight = pygame.transform.rotate(flight, 180-angle)
            elif one < 0 and two < 0:
                flight = pygame.transform.rotate(flight, -angle)
            elif one > 0 and two < 0:
                flight = pygame.transform.rotate(flight, angle-180)
            elif one < 0 and two > 0:
                flight = pygame.transform.rotate(flight, angle)
            window.blit(flight, rect_in)
        if i[2] != "Toronto":
            current = data[i[2]][0] * ((current_time - i[4]) / (i[5] - i[4]))
            one = toronto[0] - data[i[2]][2][0]
            two = toronto[1] - data[i[2]][2][1]
            ratio = two/one
            angle = abs(math.atan2(abs(two), abs(one))) / math.pi * 180
            length = 0
            width = 0
            if one < 0:
                length = abs(current / math.sqrt(ratio * ratio + 1))
            elif one > 0:
                length = -abs(current / math.sqrt(ratio * ratio + 1))
            width = length * ratio
            length *= convert
            width *= convert
            coordinates = (data[i[2]][2][0] - length, data[i[2]][2][1] - width)
            flight = model
            rect_in = flight.get_rect()
            rect_in.center = coordinates
            if one > 0 and two > 0:
                flight = pygame.transform.rotate(flight, -angle)
            elif one < 0 and two < 0:
                flight = pygame.transform.rotate(flight, 180-angle)
            elif one > 0 and two < 0:
                flight = pygame.transform.rotate(flight, angle)
            elif one < 0 and two > 0:
                flight = pygame.transform.rotate(flight, angle+180)
            window.blit(flight, rect_in)
    # mouse position
    if mouse_key[0] and sizes[0] >= mouse_pos[0] >= sizes[0]-125 and 125 >= mouse_pos[1] >= 0:
        out = True
    elif mouse_key[0] and 1350 >= mouse_pos[0] >= 1050 and 300 >= mouse_pos[1] >= 250:
        first_box = True
        second_box = False
    elif mouse_key[0] and 1350 >= mouse_pos[0] >= 1050 and 550 >= mouse_pos[1] >= 500:
        second_box = True
        first_box = False
    elif mouse_key[0]:
        first_box = False
        second_box = False
    # flight number search
    if first_box and not result1:
        if display1 >= 1350:
            bounds1 = True
        else:
            bounds1 = False
        if 15 >= cnt % 30 >= 0:
            pygame.draw.line(window, (0, 0, 0), (display1, 260), (display1, 290))
        for i in pygame.event.get():
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_BACKSPACE:
                    words1 = words1[:-1]
                elif i.key == pygame.K_RETURN:
                    words1 = ""
                elif i.key == pygame.K_SPACE:
                    if not bounds1:
                        words1 += " "
                else:
                    if not bounds1:
                        words1 += i.unicode
            result = Generate.direct(words1)
        numbers = []
        for stuff in result:
            numbers.append([stuff[0], stuff[3]])
        numbers.sort()
        if len(numbers) > 4:
            numbers = numbers[:4]
        search_input1 = font1.render(words1, False, (255, 255, 255))
        window.blit(search_input1, (1060, 260))
        display1 = 1060 + search_input1.get_size()[0]
        start = 300
        for e in range(len(numbers)):
            pygame.draw.line(window, (255, 255, 255), (1050, start), (1350, start))
            pygame.draw.line(window, (255, 255, 255), (1050, start+30), (1350, start+30))
            pygame.draw.line(window, (255, 255, 255), (1050, start), (1050, start+30))
            pygame.draw.line(window, (255, 255, 255), (1350, start), (1350, start+30))
            if mouse_key[0] and 1350 >= mouse_pos[0] >= 1050 and start+30 >= mouse_pos[1] >= start:
                words1 = str(numbers[e][0])
                result1 = True
                break
            if 1350 >= mouse_pos[0] >= 1050 and start+30 >= mouse_pos[1] >= start:
                number = font2.render(str(numbers[e][0]), False, (0, 0, 0))
                destination = font2.render(str(numbers[e][1]), False, (0, 0, 0))
                window.blit(destination, (1150, start+5))
                window.blit(number, (1060, start+5))
            else:
                number = font2.render(str(numbers[e][0]), False, (255, 255, 255))
                destination = font2.render(str(numbers[e][1]), False, (255, 255, 255))
                window.blit(destination, (1150, start+5))
                window.blit(number, (1060, start+5))
            start = 300+(e+1)*30
    elif result1:
        print(words1)
        print("RE")
    else:
        words1 = ""
    # destination search
    if second_box:
        if display2 >= 1350:
            bounds2 = True
        else:
            bounds2 = False
        if 15 >= cnt % 30 >= 0:
            pygame.draw.line(window, (0, 0, 0), (display2, 510), (display2, 540))
        for i in pygame.event.get():
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_BACKSPACE:
                    words2 = words2[:-1]
                elif i.key == pygame.K_RETURN:
                    words2 = ""
                elif i.key == pygame.K_SPACE:
                    if not bounds2:
                        words2 += " "
                else:
                    if not bounds2:
                        words2 += i.unicode
                result = Generate.pos_cities(words2)
        if len(result) > 4:
            result = result[:4]
        search_input2 = font1.render(words2, False, (255, 255, 255))
        display2 = 1060 + search_input2.get_size()[0]
        start = 550
        for e in range(len(result)):
            pygame.draw.line(window, (255, 255, 255), (1050, start), (1350, start))
            pygame.draw.line(window, (255, 255, 255), (1050, start+30), (1350, start+30))
            pygame.draw.line(window, (255, 255, 255), (1050, start), (1050, start+30))
            pygame.draw.line(window, (255, 255, 255), (1350, start), (1350, start+30))
            if mouse_key[0] and 1350 >= mouse_pos[0] >= 1050 and start+30 >= mouse_pos[1] >= start:
                words2 = str(result[e])
                break
            if 1350 >= mouse_pos[0] >= 1050 and start+30 >= mouse_pos[1] >= start:
                destination = font2.render(str(result[e]), False, (0, 0, 0))
                window.blit(destination, (1060, start+5))
            else:
                destination = font2.render(str(result[e]), False, (255, 255, 255))
                window.blit(destination, (1060, start+5))
            start = 550+(e+1)*30
        window.blit(search_input2, (1060, 510))
    else:
        words2 = ""

    pygame.display.update()
    clock.tick(60)
pygame.quit()

"""
errors & to-dos:
1) After click choice in search, it disappears ***
2) Weird things display after multiple clicks on search boxes *
3) Start displaying individual flight info *****
"""