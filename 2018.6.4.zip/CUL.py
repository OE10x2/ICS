import pygame
import Generate
pygame.init()
sizes = (1366, 768)
window = pygame.display.set_mode(sizes, pygame.FULLSCREEN)
clock = pygame.time.Clock()
quit = False

toronto = (804, 481)
back = pygame.transform.scale(pygame.image.load("Background.png"), (500, 500))
flight = pygame.transform.scale(pygame.image.load("Airplane.png"), (25, 25))
rect = back.get_rect()
rect.center = (sizes[0]/2, sizes[1]/2)
rect2 = flight.get_rect()
rect2.center = toronto
font1 = pygame.font.SysFont("Calibri", 50)
logo = pygame.transform.scale(pygame.image.load("Logo.jpg"), (125, 125))
exit_logo = pygame.transform.scale(pygame.image.load("Exit.png"), (125, 125))

flights = Generate.final_generate()
data = Generate.return_data()
cnt = 0
time = Generate.real_time()
current_time = int(time[11:][:2])*60+int(time[11:][3:])
for f in flights:
    ending = f
    print(ending)

active = []

while not quit:
    window.fill([65, 105, 225])
    pygame.event.get()
    if cnt == 60:
        time = Generate.real_time()
        current_time = int(time[11:][:2])*60+int(time[11:][3:])
        for s in flights:
            if int(s[3][:2]) * 60 + int(s[3][3:]) <= current_time <= int(s[4][:2]) * 60 + int(s[4][3:]):
                if s in active:
                    continue
                active.append(s)
            else:
                if s in active:
                    active.remove(s)
        print(len(active))
        cnt = 0
    print_time = font1.render(time, False, (255, 255, 255))
    cnt += 1
    # draw
    window.blit(print_time, (500, 0))
    window.blit(back, rect)
    window.blit(flight, rect2)
    window.blit(logo, (0, 0))
    pygame.draw.line(window, (255, 255, 255), (350, 125), (350, sizes[1]), 2)
    pygame.draw.line(window, (255, 255, 255), (0, 125), (sizes[0], 125), 3)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-350, 125), (sizes[0]-350, sizes[1]), 3)
    pygame.draw.line(window, (255, 255, 255), (350, sizes[1]-125), (sizes[0]-350, sizes[1]-125), 2)
    pygame.draw.line(window, (255, 255, 255), (sizes[0]-125, 0), (sizes[0]-125, 125), 2)
    window.blit(exit_logo, (sizes[0]-125, 0))

    mouse_pos = pygame.mouse.get_pos()
    mouse_key = pygame.mouse.get_pressed()
    if mouse_key[0] and sizes[0] >= mouse_pos[0] >= sizes[0]-125 and 125 >= mouse_pos[1] >= 0:
        quit = True

    pygame.display.update()
    clock.tick(60)
pygame.quit()